########################################################
###Kaggle上voice数据集建模
########################################################

###设定工作目录
file.choose()
setwd("E:/Rworkdirectory")#window默认存储地址用/，不是\
#载入所需要的packages
install.packages("readr")#载入所需要的packages，如未安装，需要先install.packages
installed.packages("ggplot2")
installed.packages("dplyr")
installed.packages("tidyr")
installed.packages("caret")
installed.packages("corrplot")
installed.packages("Hmisc")
installed.packages("parallel")
installed.packages("doParallel")
installed.packages("ggthemes")
require("readr")
require("ggplot2")
require("dplyr")
require("tidyr")
require("caret")
require("corrplot")
require("Hmisc")
require("parallel")
require("doParallel")
require("ggthemes")

###导入所需要的数据并且描述
#导入数据
voice_Original <- read_csv("voice.csv",col_names=TRUE) 
#描述
describe(voice_Original)

###缺失值处理
#由于本数据没有缺失值，因此先将第一列的30个数据设为缺失
set.seed(1001)
random_number <- sample(1:3168,30)
voice_Original1 <- voice_Original
voice_Original[random_number,1] <- NA
describe(voice_Original)
#插补缺失值
original_Import <- preProcess(voice_Original,method = "bagImpute")
voice_Original1 <- predict(original_Import,voice_Original)
#比较插值效果
compare_Imputation <- data.frame(
  voice_Original1[random_number,1],
  voice_Original[random_number,1]
)
compare_Imputation

###将一个因子转换成类别数据
voice_Original <- voice_Original %>%
  mutate(ap.ent=
           ifelse(sp.ent > 0.9, "High", "Low"))

###可视化
voice_Original %>%
  ggplot(aes(x = meanfreq, y = dfrange))+
  geom_point(aes(color = label))+
  theme_wsj()

###研究可预测因子的相关性 
factor_Corr <- cor(voice_Original[,-c(9,21)]) 
corrplot(factor_Corr,method="number")

###数据建模与分配
#将70%的数据作为训练集，剩下30%作为测试集
sample_Index <- createDataPartition(voice_Original$label, p = 0.7, list = FALSE) 
voice_Train <- voice_Original[sample_Index, ] 
voice_Test <- voice_Original[-sample_Index, ]

###标准化统一量纲，再使用主成分分析消除因子中的高相关性 
pp <- preProcess(voice_Train, method = c("scale", "center", "pca"))
voice_Train <- predict(pp,voice_Train)
voice_Test <- predict(pp,voice_Test)

###建模准备
#设置函数
model_Formula <- label-PC1 + PC2 + PC3 + PC4 + PC5 + PC6 + PC7 + 
  PC8 + PC9 + PC10 + ap.ent

#设交叉验证参数
modelControl <- trainControl(method = "repeatedcv", number = 5, 
                             repeats = 5, allowParallel = TRUE)

###建立模型
#逻辑回归模型
glm_Model1 <- train(model_Formula,
                    data = voice_Train, 
                    method = "glm", 
                    trControl = modelControl)
#在测试集中比较
voice_Test1 <- voice_Test[, -2]
voice_Test1$glmPrediction <- predict(glm_Model1, voice_Test1)
table(voice_Test$label, voice_Test1$glmPrediction)
#线性判别分析(LDA)
lda_Model <- train(model_Formula,
                   data = voice_Train,
                   method = "lda",
                   trControl = modelControl)
#在测试集中比较
voice_Test1$ldaPrediction <- predict(lda_Model1, voice_Test1)
table(voice_Test$label, voice_Test1$ldaPrediction)
#随机森林
lda_Model <- train(model_Formula,
                   data = voice_Train,
                   method = "rf",
                   trControl = modelControl,
                   ntrees = 500)
#在测试集中比较
voice_Test1$rfPrediction <- predict(rf_Model1, voice_Test1)
table(voice_Test$label, voice_Test1$rfPrediction)

###将三个模型进行比较
model_Comparision <- 
  resamples(list(
    LogisticRegression = glm_Model1,
    LinearDiscrimnant = lda_Model, 
    RandomForest = rf_Model
  ))
summary(model_Comparision)
bwplot(model_Comparision, layout = c(2,1))

###逻辑回归的结果表现的最好


